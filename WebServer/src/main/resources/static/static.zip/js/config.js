var config = {
	host: 'http://localhost:3000'
}