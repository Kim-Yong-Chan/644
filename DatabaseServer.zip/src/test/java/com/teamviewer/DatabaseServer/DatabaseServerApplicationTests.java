package com.teamviewer.DatabaseServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatabaseServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
