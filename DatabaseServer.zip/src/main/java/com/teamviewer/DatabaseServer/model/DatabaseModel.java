package com.teamviewer.DatabaseServer.model;


public class DatabaseModel {
    private int roomId;//방번호
    private String query;//받아온 Query

    public DatabaseModel() {

    }
}
