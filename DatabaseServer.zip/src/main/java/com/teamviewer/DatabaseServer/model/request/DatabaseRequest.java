package com.teamviewer.DatabaseServer.model.request;

public class DatabaseRequest {
    //getRoomId, getQuery구현
    private String roomId;
    private String query;

    public DatabaseRequest() {
    }

    public String getRoomId() {
        return roomId;
    }

    public String getQuery() {
        return query;
    }


}
