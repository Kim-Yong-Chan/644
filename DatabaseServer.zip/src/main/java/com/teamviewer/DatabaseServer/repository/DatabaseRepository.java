package com.teamviewer.DatabaseServer.repository;


import org.springframework.stereotype.Repository;

@Repository
public interface DatabaseRepository {

}
